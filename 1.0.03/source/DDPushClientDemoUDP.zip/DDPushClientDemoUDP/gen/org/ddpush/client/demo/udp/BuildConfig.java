/** Automatically generated file. DO NOT MODIFY */
package org.ddpush.client.demo.udp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}