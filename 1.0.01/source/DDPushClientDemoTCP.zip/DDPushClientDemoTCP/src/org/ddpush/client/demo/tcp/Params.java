package org.ddpush.client.demo.tcp;

public class Params {
	public static String DEFAULT_PRE_NAME = "defaultAccount";
	public static String SERVER_IP = "serverIp";
	public static String SERVER_PORT = "serverPort";
	public static String PUSH_PORT = "pushPort";
	public static String USER_NAME = "userName";
	public static String SENT_PKGS = "sentPkgs";
	public static String RECEIVE_PKGS = "receivePkgs";
}
