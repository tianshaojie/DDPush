/** Automatically generated file. DO NOT MODIFY */
package org.ddpush.client.demo.tcp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}